
#ifndef __TYPES_H__
#define __TYPES_H__

#define TRUE 1
#define FALSE 0

typedef enum {_FALSE=0, _TRUE=1} BOOL;

typedef unsigned char byte;
typedef unsigned short word;
typedef unsigned long dword;

#endif /* __TYPES_H__ */
